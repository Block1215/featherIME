package dev.bl.feathercaramel.mixin;

import dev.bl.feathercaramel.FeatherCaramelChatClient;
import net.minecraft.class_310;
import net.minecraft.class_437;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * 画面遷移のたびに IController.changeFocusedScreen() を呼び、
 * フォーカス中の Operator を適切にクリアする。
 */
@Mixin(class_310.class)
public class MixinMinecraft {

    @Inject(method = "setScreen", at = @At("HEAD"), require = 0)
    private void featherCaramel$setScreen(final class_437 screen, final CallbackInfo ci) {
        FeatherCaramelChatClient.getController().changeFocusedScreen(screen);
    }
}
