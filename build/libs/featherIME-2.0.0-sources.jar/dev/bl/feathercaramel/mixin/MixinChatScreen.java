package dev.bl.feathercaramel.mixin;

import dev.bl.feathercaramel.controller.EditBoxController;
import dev.bl.feathercaramel.driver.KeyboardStatus;
import dev.bl.feathercaramel.wrapper.WrapperEditBox;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_3532;
import net.minecraft.class_408;
import net.minecraft.class_437;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Feather 対策:
 *   - @Shadow は fabricloader がリマップできるフィールドのみ使用
 *   - commandSuggestions は refMap なしでは見つからないため削除
 *   - IMEインジケーターの位置はシンプルに左下固定にする
 */
@Mixin(class_408.class)
public abstract class MixinChatScreen extends class_437 {

    protected MixinChatScreen() { super(class_2561.method_43473()); }

    @Shadow protected class_342 input;
    // commandSuggestions の @Shadow は Feather 環境で refMap なしだと失敗するため削除

    @Unique private static final int TOOLTIP_TIME = 500;
    @Unique private static final int FADE_TIME    = 250;
    @Unique private static KeyboardStatus.Language featherCaramel$lastLang;
    @Unique private static long                    featherCaramel$changeTime;

    @Inject(method = "init", at = @At("TAIL"), require = 0)
    private void featherCaramel$onInit(final CallbackInfo ci) {
        featherCaramel$lastLang = null;
        if (this.input == null) return;
        final WrapperEditBox w = EditBoxController.getWrapper(this.input);
        if (w != null) w.setFocused(true);
    }

    @Inject(method = "removed", at = @At("HEAD"), require = 0)
    private void featherCaramel$onRemoved(final CallbackInfo ci) {
        if (this.input == null) return;
        final WrapperEditBox w = EditBoxController.getWrapper(this.input);
        if (w != null) w.setFocused(false);
    }

    @Inject(method = "render", at = @At("HEAD"), require = 0)
    private void featherCaramel$render(
            final class_332 g, final int mx, final int my, final float td, final CallbackInfo ci) {
        featherCaramel$renderImeStatus(g);
    }

    @Unique
    private void featherCaramel$renderImeStatus(final class_332 g) {
        if (this.input == null) return;
        final WrapperEditBox wrapper = EditBoxController.getWrapper(this.input);
        if (wrapper == null) return;

        final KeyboardStatus status = wrapper.getIme().getController().getKeyboardStatus();
        if (status == null) return;

        final long now = System.currentTimeMillis();
        final var curLang = status.language();
        if (featherCaramel$lastLang != curLang) {
            featherCaramel$lastLang   = curLang;
            featherCaramel$changeTime = now;
        }

        final int elapsed = (int)(now - featherCaramel$changeTime);
        if (elapsed > TOOLTIP_TIME) return;

        // Font は Screen が持つ protected フィールド — Mixin が extends Screen なのでアクセス可能
        final class_2561 display = class_2561.method_43470(status.display());
        final int textW = this.field_22793.method_27525(display);
        final int bsx = 2;
        final int bex = bsx + class_3532.method_15375(textW - status.offset()) + 4;
        final int bey = this.field_22790 - 14 - 2;
        final int bsy = bey - this.field_22793.field_2000 - 2;

        final int backColor = featherCaramel$fade(
            class_310.method_1551().field_1690.method_19344(Integer.MIN_VALUE), elapsed);
        final int textColor = featherCaramel$fade(0xFFFFFFFF, elapsed);
        if (backColor == 0 && textColor == 0) return;

        g.method_25294(bsx, bsy, bex, bey, backColor);
        g.method_51439(this.field_22793, display, bsx + 2, bsy + 1, textColor, false);
    }

    @Unique
    private int featherCaramel$fade(final int color, final int elapsed) {
        if (elapsed < FADE_TIME) return color;
        final int   a = (color >> 24) & 0xFF;
        final float p = (float)(TOOLTIP_TIME - elapsed) / FADE_TIME;
        final int   r = (int)(p * a);
        return r < 5 ? 0 : (r << 24) | (color & 0x00FFFFFF);
    }
}
