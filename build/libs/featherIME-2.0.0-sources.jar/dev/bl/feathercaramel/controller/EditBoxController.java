package dev.bl.feathercaramel.controller;

import dev.bl.feathercaramel.wrapper.WrapperEditBox;
import net.minecraft.class_342;

/**
 * MixinEditBox が実装するインターフェース。
 * EditBox インスタンスから WrapperEditBox を取得するためのブリッジ。
 */
public interface EditBoxController {

    static WrapperEditBox getWrapper(final class_342 box) {
        return ((EditBoxController) box).featherCaramel$wrapper();
    }

    WrapperEditBox featherCaramel$wrapper();
}
