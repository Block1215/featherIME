package dev.bl.feathercaramel.wrapper;

import dev.bl.feathercaramel.util.Rect;
import net.minecraft.class_342;

/**
 * EditBox 用 IME ラッパー。
 * accesswidener で開放した EditBox のフィールドに直接アクセスする。
 */
public final class WrapperEditBox extends AbstractIMEWrapper {

    private final class_342 wrapped;
    private Runnable insertCallback = () -> {};

    public WrapperEditBox(final class_342 box) {
        super(box.field_2092);
        this.wrapped = box;
    }

    @Override
    protected void insert(final String text) {
        if (editable()) {
            wrapped.method_1867(text);
            insertCallback.run();
        }
    }

    @Override protected int getCursorPos()    { return wrapped.field_2102; }
    @Override protected int getHighlightPos() { return wrapped.field_2101; }

    @Override
    public boolean editable() { return wrapped.method_20315(); }

    @Override
    public boolean blockTyping() {
        if (!wrapped.method_20315()) return true;
        final int start  = Math.min(wrapped.field_2102, wrapped.field_2101);
        final int end    = Math.max(wrapped.field_2102, wrapped.field_2101);
        final int remain = (wrapped.field_2108 - wrapped.field_2092.length()) - (start - end);
        return remain <= 0;
    }

    @Override
    protected String getTextWithPreview() { return wrapped.field_2092; }

    @Override
    protected void setPreviewText(final String text) {
        valueChanged = true;
        wrapped.method_1852(text);
        if (wrapped.method_25370()) insertCallback.run();
    }

    @Override
    public Rect getRect() {
        final int   xWidth = wrapped.field_2105.method_1727(wrapped.field_2092.substring(0, wrapped.method_1881()));
        final float x      = xWidth + wrapped.method_46426() + (wrapped.field_2095 ? 4 : 0);
        final float y      = wrapped.field_2105.field_2000 + wrapped.method_46427()
                             + (wrapped.field_2095 ? ((wrapped.method_25364() - 8) / 2.0f) : 0);
        return new Rect(x, y, wrapped.method_25368(), wrapped.method_25364());
    }

    public void setInsertCallback(final Runnable cb) { insertCallback = cb; }
}
