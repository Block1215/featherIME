package dev.bl.feathercaramel.mixin;

import dev.bl.feathercaramel.controller.EditBoxController;
import dev.bl.feathercaramel.wrapper.AbstractIMEWrapper;
import dev.bl.feathercaramel.wrapper.WrapperEditBox;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;
import net.minecraft.class_124;
import net.minecraft.class_2583;
import net.minecraft.class_342;
import net.minecraft.class_5481;

/**
 * EditBox に IME プリエディット表示・確定入力・フォーカス制御を追加する。
 *
 * priority = 0 → Feather の EditBox Mixin より先に適用されることで
 * 初期化タイミングの競合を避ける。
 * require = 0  → インジェクション失敗でクラッシュしない。
 */
@Mixin(value = class_342.class, priority = 0)
public abstract class MixinEditBox implements EditBoxController {

    @Unique private WrapperEditBox featherCaramel$wrapper;
    @Unique private int            featherCaramel$cacheCursor;
    @Unique private int            featherCaramel$cacheHighlight;

    @Shadow private boolean canLoseFocus;
    @Shadow public  int     highlightPos;
    @Shadow public  int     cursorPos;
    @Shadow public  String  value;
    @Shadow @Final  private List<class_342.class_11734> formatters;

    // ---- EditBoxController 実装 ----
    @Override
    public WrapperEditBox featherCaramel$wrapper() { return featherCaramel$wrapper; }

    // ---- 初期化 ----

    /**
     * コンストラクタ内 setValue() を Redirect してラッパーを生成。
     * これにより「setValue が呼ばれた瞬間」にラッパーが存在する。
     */
    @Redirect(
        method = "<init>(Lnet/minecraft/client/gui/Font;IIIILnet/minecraft/client/gui/components/EditBox;Lnet/minecraft/network/chat/Component;)V",
        at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/components/EditBox;setValue(Ljava/lang/String;)V"),
        require = 0
    )
    private void featherCaramel$initRedirect(final class_342 self, final String value) {
        featherCaramel$wrapper = new WrapperEditBox((class_342) (Object) this);
        self.method_1852(value);
    }

    /** フォールバック: Redirect が失敗した場合でもコンストラクタ末尾で確実に初期化。 */
    @Inject(
        method = "<init>(Lnet/minecraft/client/gui/Font;IIIILnet/minecraft/client/gui/components/EditBox;Lnet/minecraft/network/chat/Component;)V",
        at = @At("TAIL"),
        require = 0
    )
    private void featherCaramel$lazyInit(final CallbackInfo ci) {
        if (featherCaramel$wrapper == null) {
            featherCaramel$wrapper = new WrapperEditBox((class_342) (Object) this);
        }
        // プリエディットテキストに下線を引くフォーマッタを追加
        formatters.add(featherCaramel$caretFormatter());
    }

    // ---- TextFormatter (プリエディット下線表示) ----

    @Unique
    private class_342.class_11734 featherCaramel$caretFormatter() {
        return (original, firstPos) -> {
            if (featherCaramel$wrapper == null) return null;

            final AbstractIMEWrapper.InputStatus st = featherCaramel$wrapper.getStatus();
            if (st == AbstractIMEWrapper.InputStatus.NONE) {
                return null; // 通常表示
            }
            if (featherCaramel$wrapper.blockTyping()) {
                // 入力上限: 赤色で警告
                return class_5481.method_30747(original, class_2583.field_24360.method_10977(class_124.field_1061));
            }

            // プリエディット区間: firstEndPos 〜 secondStartPos を下線表示
            final int lastPos = firstPos + original.length();
            if (lastPos <= featherCaramel$wrapper.getFirstEndPos()
                    || featherCaramel$wrapper.getSecondStartPos() < firstPos) {
                return null;
            }

            final int firstLen   = featherCaramel$wrapper.getFirstEndPos() - firstPos;
            final int previewLen = featherCaramel$wrapper.getSecondStartPos()
                                   - featherCaramel$wrapper.getFirstEndPos();
            final int inputEnd   = Math.min(original.length(), firstLen + previewLen);

            final List<class_5481> list = new ArrayList<>();
            list.add(class_5481.method_30747(original.substring(0, firstLen),       class_2583.field_24360));
            list.add(class_5481.method_30747(original.substring(firstLen, inputEnd), class_2583.field_24360.method_30938(true)));
            list.add(class_5481.method_30747(original.substring(inputEnd),           class_2583.field_24360));
            return class_5481.method_30749(list);
        };
    }

    // ---- setValue フック ----

    @Inject(method = "setValue", at = @At("HEAD"), require = 0)
    private void featherCaramel$setValueHead(final String text, final CallbackInfo ci) {
        if (featherCaramel$wrapper != null && featherCaramel$wrapper.valueChanged) {
            featherCaramel$cacheCursor    = 0;
            featherCaramel$cacheHighlight = 0;
        } else {
            featherCaramel$setStatusToNone();
        }
    }

    @Redirect(
        method = "setValue",
        at = @At(value = "INVOKE", target = "Ljava/util/function/Predicate;test(Ljava/lang/Object;)Z"),
        require = 0
    )
    private boolean featherCaramel$setValueTest(final Predicate<String> pred, final Object v) {
        if (featherCaramel$wrapper != null && featherCaramel$wrapper.valueChanged) {
            featherCaramel$cacheCursor    = cursorPos;
            featherCaramel$cacheHighlight = highlightPos;
            return true;
        }
        return pred.test((String) v);
    }

    @Inject(
        method = "setValue",
        at = @At(value = "INVOKE", shift = At.Shift.BEFORE,
                 target = "Lnet/minecraft/client/gui/components/EditBox;moveCursorToEnd(Z)V"),
        cancellable = true,
        require = 0
    )
    private void featherCaramel$setValueInvoke(final String text, final CallbackInfo ci) {
        if (featherCaramel$wrapper != null && featherCaramel$wrapper.valueChanged) {
            ci.cancel();
            cursorPos    = featherCaramel$cacheCursor;
            highlightPos = featherCaramel$cacheHighlight;
            featherCaramel$wrapper.valueChanged = false;
            return;
        }
        featherCaramel$forceUpdateOrigin();
    }

    // ---- insertText フック ----

    @Inject(method = "insertText", at = @At("HEAD"), require = 0)
    private void featherCaramel$insertTextHead(final String text, final CallbackInfo ci) {
        featherCaramel$setStatusToNone();
    }

    @Inject(
        method = "insertText",
        at = @At(value = "INVOKE", shift = At.Shift.BEFORE,
                 target = "Lnet/minecraft/client/gui/components/EditBox;onValueChange(Ljava/lang/String;)V"),
        require = 0
    )
    private void featherCaramel$insertTextInvoke(final String text, final CallbackInfo ci) {
        featherCaramel$forceUpdateOrigin();
    }

    @Inject(method = "onValueChange", at = @At("HEAD"), require = 0)
    private void featherCaramel$onValueChange(final String text, final CallbackInfo ci) {
        if (featherCaramel$wrapper != null) {
            value = featherCaramel$wrapper.getOrigin();
        }
    }

    @Inject(
        method = "deleteCharsToPos",
        at = @At(value = "INVOKE", shift = At.Shift.BEFORE,
                 target = "Lnet/minecraft/client/gui/components/EditBox;moveCursorTo(IZ)V"),
        require = 0
    )
    private void featherCaramel$deleteChars(final int pos, final CallbackInfo ci) {
        if (featherCaramel$wrapper != null) featherCaramel$wrapper.setOrigin(value);
    }

    // ---- setFocused フック ----

    @Inject(method = "setFocused", at = @At("TAIL"), require = 0)
    private void featherCaramel$setFocused(final boolean focused, final CallbackInfo ci) {
        if (featherCaramel$wrapper != null) {
            featherCaramel$wrapper.setFocused(focused || !canLoseFocus);
        }
    }

    @Inject(method = "setCanLoseFocus", at = @At("HEAD"), require = 0)
    private void featherCaramel$setCanLoseFocus(final boolean canLoseFocus, final CallbackInfo ci) {
        if (featherCaramel$wrapper != null && !canLoseFocus) {
            featherCaramel$wrapper.setFocused(true);
        }
    }

    // ---- ユーティリティ ----

    @Unique
    private void featherCaramel$setStatusToNone() {
        if (featherCaramel$wrapper != null) featherCaramel$wrapper.setToNoneStatus();
    }

    @Unique
    private void featherCaramel$forceUpdateOrigin() {
        if (featherCaramel$wrapper != null) featherCaramel$wrapper.setOrigin(value);
    }
}
